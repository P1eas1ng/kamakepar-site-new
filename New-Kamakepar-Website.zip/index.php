<?php
$user = $_GET['user'];
if (isset($_GET['user']) == false){
  $user = 'User';
}
$por = $_SERVER["REMOTE_PORT"];
$addr = $_SERVER["REMOTE_ADDR"];
function transform($file, $args){
   $htmlfile = file_get_contents($file);
   if ($args != ''){
   $json_args = json_decode($args);
   $name = $json_args->name;
   $port = $json_args->port;
   $ip = $json_args->ip;
   $name_transform = str_replace("%NAME%",$name,$htmlfile);
   $port_transform = str_replace("%PATH%",$port,$name_transform);
   $ip_transforms = str_replace("%IP%",$ip,$port_transform);
   $ready_file = $ip_transforms;
   }else{
   $ready_file = $htmlfile;
   }
   return $ready_file;
}
$file_with_pass = 'all.json';
if($_SERVER['PATH_INFO'] =='') 
{
  $args = '{"name":"'.$user.'","port":"'.$por.'", "ip":"'.$addr.'"}';
  $files = transform('templates/index.html', $args);  
    echo $files;
}

elseif($_SERVER['PATH_INFO'] =='/templates'){
  echo '<br>';
    echo '<center><img class="MMImage-Origin" src="https://im0-tub-ru.yandex.net/i?id=ed51abb7f3587b8dd727255ebd8d7115-l&amp;n=13"></center>';
}
 else {
    echo '<br>';
    echo '<center><img class="MMImage-Origin" src="https://im0-tub-ru.yandex.net/i?id=ed51abb7f3587b8dd727255ebd8d7115-l&amp;n=13"></center>';
}
?>